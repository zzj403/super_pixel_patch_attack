# -*- coding: utf-8 -*-
'''
@Time          : 2020/05/06 15:07
@Author        : Tianxiaomo
@File          : train.py
@Noice         :
@Modificattion :
    @Author    :
    @Time      :
    @Detail    :

'''

import torch

from tqdm import tqdm
from dataset import Yolo_dataset
from cfg import Cfg

def dataset():
    pass


def train_epoch():
    pass


def train():
    pass


if __name__ == "__main__":
    train()
